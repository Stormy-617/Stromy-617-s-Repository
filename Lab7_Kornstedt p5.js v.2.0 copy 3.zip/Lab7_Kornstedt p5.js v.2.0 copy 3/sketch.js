let myLogo;
let fireGif;

function preload() {
  myLogo = loadImage('/Assets/logo Post.png');
  fireGif = loadImage('/Assets/fire-flames-transparent.gif')
}

function setup() {
  createCanvas(400, 400);
  
}

function draw() {
  background(255);
  image(myLogo,0,0,400,400); //My own design
  image(fireGif,50,275,100,100);
  image(fireGif,250,275,100,100); 
  image(fireGif,mouseX,mouseY,50,50);
  //https://onlinegiftools.com/images/examples-onlinegiftools/fire-flames-transparent.gif
  
  fill('red');
  stroke(10)
  textFont('Gotham');
  textSize(18);
  text('Play my game!', 135, 50, 400, 400)
} 