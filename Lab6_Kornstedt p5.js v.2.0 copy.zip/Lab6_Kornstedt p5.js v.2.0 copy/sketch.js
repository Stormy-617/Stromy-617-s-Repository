//Cloud Bumps
let cloudBumpY = 50;
let cloudBumpX = 0;
let cloudBumpD = 0;

//Snow Variables
let snowflakeX = 0;
let snowflakeY = [];
let snowflakeD = 5;

//Snowflake Frequency
let amount = 400;

//Mouse design array
let mouseDesignX = [];
let mouseDesignY = [];

function setup() {
  createCanvas(400, 400);
  background(25);
  
  for (let i = 0; i <= amount; i++) {
    snowflakeY[i] = 0;
  }
}

function draw() {
  frameRate(5);
  
  background(25);
  
  //Snowy-Foreground
  noStroke();
  fill(255);
  rect(0,200,400,200);
  noFill();

  for (let i = 0; i <= snowflakeY.length-1; i++) {
    stroke(0);
    strokeWeight(0.2);
    fill(255);
    circle(snowflakeX,i,snowflakeD);
    snowflakeX = random(0,400);
  }//End for loop
  
  //Trees
  fill("rgb(126,33,33)");
  rect(50,0,20,400);
  
  fill("rgb(126,33,33)");
  rect(200,-400,20,750);
  
  fill("rgb(126,33,33)");
  rect(350,0,20,750);
  
  strokeWeight(10);
  stroke("rgb(126,33,33)");
  line(60,200,100,100);
  
  strokeWeight(10);
  stroke("rgb(126,33,33)");
  line(205,250,150,100);
  
  strokeWeight(10);
  stroke("rgb(126,33,33)");
  line(205,200,250,100);
  
  strokeWeight(10);
  stroke("rgb(126,33,33)");
  line(350,200,300,100);
  noStroke();
  
  //Grey Clouds
  noStroke();
  fill(50);
  rect(0,0,400,50);
  noFill();
  
  //Prints info on bumpcloud positions
  print(cloudBumpD);
  print(cloudBumpX);
  print(cloudBumpY);
  
  //Randomizes the bumps on the clouds
  for (let i2 = 0; i2 <= 50; i2++) {
    fill(50);
    circle(cloudBumpX,cloudBumpY,cloudBumpD)
    cloudBumpD = random(50,100);
    cloudBumpX = random(0,400);
    cloudBumpY = random(55,45);
  }//Ends for loop 
  
  mouseDesignX[0] = mouseX;
  mouseDesignY[0] = mouseY;
  
  for (let i3 = 0; i3 <= 400; i3++) {
    fill(i3 * 4);
    ellipse(mouseDesignX[i3], mouseDesignY[i3], 20, 20);
  }
  
}