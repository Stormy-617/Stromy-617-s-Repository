/*Instructions:
Click the window to use the Arrow keys!
Try to cover the entire canvas in black without lossing your cirlce!
Good Luck!
*/

//Global Variables
let x = 200;
let y = 200;
let d = 25
let moveSpeed = 2.5;

//Basic Movement
function draw() {
  if (keyIsPressed === true) {
    if (keyCode === UP_ARROW) {
      y -= moveSpeed;
    } else if (keyCode === DOWN_ARROW) {
      y += moveSpeed;
    } else if (keyCode === LEFT_ARROW) {
      x -= moveSpeed;
    } else if (keyCode === RIGHT_ARROW) {
      x += moveSpeed;
    }
  }

  ellipse(x,y,d,d);
  
}

//BackDrop
function setup() {
  createCanvas(400, 400);
  background(255);
  
  fill(0);
  let blkBar = 0;
  for(blkBar; blkBar < width; blkBar += 50) {
    rect(blkBar,0,25,400);
  }
}

//Reset
function mousePressed() {
  background(255);
  
  fill(0);
  let blkBar = 0;
  for(blkBar; blkBar < width; blkBar += 50) {
  rect(blkBar,0,25,400);
  }
}